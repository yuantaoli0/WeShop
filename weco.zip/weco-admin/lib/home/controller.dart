import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';
import 'package:sdk/xcontroller.dart';

class HomeController extends GetxController {
  @override
  void onInit() {
    super.onInit();
  }
}
