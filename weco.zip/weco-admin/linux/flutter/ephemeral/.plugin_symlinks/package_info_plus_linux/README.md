# Package Info Plus Linux

[![Flutter Community: package_info_plus_linux](https://fluttercommunity.dev/_github/header/package_info_plus_linux)](https://github.com/fluttercommunity/community)

[![pub package](https://img.shields.io/pub/v/package_info_plus_linux.svg)](https://pub.dev/packages/package_info_plus_linux)

The Linux implementation of [`package_info_plus`](https://pub.dev/packages/package_info_plus).

## Usage

This package is already included as part of the `package_info_plus` package dependency, and will
be included when using `package_info_plus` as normal.
