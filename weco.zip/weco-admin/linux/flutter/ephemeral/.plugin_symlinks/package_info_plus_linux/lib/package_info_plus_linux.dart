/// The Linux implementation of `package_info_plus`.
library package_info_plus_linux;

export 'src/package_info.dart';
