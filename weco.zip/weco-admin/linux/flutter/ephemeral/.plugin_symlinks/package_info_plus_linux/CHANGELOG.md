## 1.0.5

- Resolve package_name

## 1.0.4

- Fix MissingPluginException

## 1.0.3
- Add `buildSignature` to Android package info to retrieve the signing certifiate SHA1 at runtime.

## 1.0.2

- Fix async loading: #247

## 1.0.1

- Improve documentation

## 1.0.0

- Migrate to null-safety
- Update dependencies
- Fix dart SDK constraints

## 0.1.1

- Fix platform interface dependency version

## [0.1.0]

- Initial version for Linux.
