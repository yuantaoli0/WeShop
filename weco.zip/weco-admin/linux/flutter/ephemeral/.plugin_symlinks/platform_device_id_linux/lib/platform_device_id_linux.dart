// The platform_device_id_platform_interface defaults to MethodChannelPlatformDeviceId
// as its instance, which is all the linux implementation needs. This file
// is here to silence warnings when publishing to pub.
