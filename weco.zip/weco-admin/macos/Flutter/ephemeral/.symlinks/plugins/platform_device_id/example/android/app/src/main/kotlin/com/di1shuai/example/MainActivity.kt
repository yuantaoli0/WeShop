package com.di1shuai.example

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
