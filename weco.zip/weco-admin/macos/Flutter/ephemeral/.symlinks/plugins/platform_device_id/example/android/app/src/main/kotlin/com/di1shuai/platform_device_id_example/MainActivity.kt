package com.di1shuai.platform_device_id_example

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
