## 1.0.1
update dependencies

## 1.0.0
support native windows. 
now , it's stable for android/ios/macos/linux/windows/web platform.

## 0.5.0
support native web

## 0.4.1
linux support null safety

## 0.4.0
support native linux

## 0.3.1
update dependencies

## 0.3.0
refactory to federated plugin

## 0.2.1
update readme usage e.g for null safety

## 0.2.0
upgrade dependency & support flutter 2.x & null safety

## 0.1.3-nullsafety
upgrade dependency

## 0.1.3
support native macos

## 0.1.2
upgrade dependency

## 0.1.1
fix bug for go-flutter in linux

## 0.1.0

support android、ios、

## 0.0.1

support go-flutter for windows、linux、mac