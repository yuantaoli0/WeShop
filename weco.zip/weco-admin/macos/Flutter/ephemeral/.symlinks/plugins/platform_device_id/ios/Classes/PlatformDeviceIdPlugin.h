#import <Flutter/Flutter.h>

@interface PlatformDeviceIdPlugin : NSObject<FlutterPlugin>
@end
