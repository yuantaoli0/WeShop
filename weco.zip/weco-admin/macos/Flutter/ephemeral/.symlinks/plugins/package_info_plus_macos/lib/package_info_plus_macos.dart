// The package_info_platform_interface defaults to MethodChannelPackageInfo
// as its instance, which is all the macOS implementation needs. This file
// is here to silence warnings when publishing to pub.
