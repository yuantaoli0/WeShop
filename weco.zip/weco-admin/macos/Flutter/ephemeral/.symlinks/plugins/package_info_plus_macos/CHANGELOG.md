## 1.3.0

- Removed `Reachability` dependency

## 1.2.0

- fix app name on macOS

## 1.1.1

- Improve documentation

## 1.1.0

- Renamed plugin class to avoid collision with package_info

## 1.0.0

- Migrate to null-safety
- Update dependencies
- Fix dart SDK constraints

## 0.2.0

- Changed method channel name

## 0.1.0

- Transfer to plus-plugins monorepo

# 0.0.1

- Initial release.
