#import <Flutter/Flutter.h>

@interface AudioplayersDarwinPlugin : NSObject<FlutterPlugin>
@end
