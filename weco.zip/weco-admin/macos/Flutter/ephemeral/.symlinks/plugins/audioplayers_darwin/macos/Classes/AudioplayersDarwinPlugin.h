#import <FlutterMacOS/FlutterMacOS.h>

@interface AudioplayersDarwinPlugin : NSObject<FlutterPlugin>
@end
