## 2.1.1

* Fixes a regression in the path retured by `getApplicationSupportDirectory` on iOS.

## 2.1.0

* Renames the package previously published as
  [`path_provider_macos`](https://pub.dev/packages/path_provider_macos)
* Adds iOS support.
