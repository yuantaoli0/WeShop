abstract class XBaseLocal {
  String get name;

  Map<String, Map<String, String>> get keys;
}
